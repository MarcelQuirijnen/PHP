<?php

$url = 'https://www.carvana.com/cars';

$db_host='localhost';
$db_database='consumer_edge';
$db_username='root';
$db_passwd='urashuto';

$PAGE = 0;
$ALL = 0;